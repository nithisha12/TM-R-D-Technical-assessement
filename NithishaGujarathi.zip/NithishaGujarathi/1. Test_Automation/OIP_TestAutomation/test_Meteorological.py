#for selenium
#pip install selenium

# to install webdriver
#pip install webdriver_manager

# We can generate HTML reports with our Selenium test using the Pytest Testing Framework
# pip install pytest

#pytest version check
#pytest –version

from selenium import webdriver
from time import sleep #for sleep we use this to load the all html elements
#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import unittest
import pytest as pytest
from selenium.webdriver.common.action_chains import ActionChains

# inherit TestCase Class and create a new test class
class AirSelangorTweet(unittest.TestCase):

    #initiation of webdriver
    def setUp(self):
        self.driver = webdriver.Chrome();

    #Test Case Method. It Should always start with test_
    def test_AirSelangorTweet(self):

        try:
            #get driver
            driver = self.driver
            driver.get("https://store.oip.tmrnd.com.my/")

            #maximize the windows
            driver.maximize_window()
            sleep(5)

            driver.find_element(
                By.XPATH,'/html/body/app-root/nb-layout/div/div/nb-layout-header/nav/app-header/section/button[3]'
            ).click()
            sleep(2)

            driver.find_element(By.XPATH,'//*[@id="usernameUserInput"]').send_keys('nithishanithu707@gmail.com')
            driver.find_element(By.XPATH,'//*[@id="password"]').send_keys('Srini@3004')
            driver.find_element(By.XPATH,'//*[@id="loginForm"]/div[10]/div[2]/button').click()
            sleep(10)

            driver.find_element(By.XPATH,'/html/body/app-root/nb-layout/div/div/div/div/div/nb-layout-column/app-api-listing/div[2]/div[1]/div[2]/input').send_keys('Meteorological-Malaysia')
            driver.find_element(By.XPATH,'/html/body/app-root/nb-layout/div/div/div/div/div/nb-layout-column/app-api-listing/div[2]/div[1]/div[2]/button').click()

            sleep(5)
            driver.find_element(By.XPATH,'/html/body/app-root/nb-layout/div/div/div/div/div/nb-layout-column/app-api-listing/div[2]/div[2]/div[2]/div[1]/div[2]/nb-card/nb-card-body/div[2]/button').click()
            sleep(5)

            isSubscribeEnabled = driver.find_element(By.XPATH, '/html/body/app-root/nb-layout/div/div/div/div/div/nb-layout-column/app-api-overview/div/div/div/nb-card/nb-card-body/app-api-information/div/div[1]/div/button').is_enabled()
            print(isSubscribeEnabled)
            if isSubscribeEnabled:
                print("Login is success")
                driver.find_element(By.XPATH,'/html/body/app-root/nb-layout/div/div/div/div/div/nb-layout-column/app-api-overview/div/div/div/nb-card/nb-card-body/app-api-information/div/div[1]/div/button').click()
                sleep(5)
                driver.find_element(By.XPATH,'//*[@id="cdk-overlay-0"]/nb-dialog-container/app-api-subscription/nb-card/nb-card-footer/div/button[2]').click()
                sleep(5)
            else:
                print("Login is fail")

        except:
            print("Exception Occurred, Hence closing the browser")
            pytest.fail("Exception Occurred, closing the browser")
            # close web browser
            self.driver.close()

    # cleanup method called after every test performed
    def tearDown(self):
        # close web browser
        self.driver.close()

# it allows to execute code when the file runs as script
if __name__ == "__main__":
    unittest.main()

# To run a Pytest file, we can open the terminal and move from the current directory
# to the directory of the Pytest file that we want to execute
# Ex:C:\Users\User\OneDrive\Desktop\TM_Tasks\Test_Automation\OIP_TestAutomation
# py.test -v -s.

# To generate a HTML report for a Selenium test, we have to install a plugin :
# pip install pytest-html

# To generate the report, we have to move from the current directory
# to the directory of the Pytest file that we want to execute.
# Then run the command:
# pytest --html=report.html.
